package com.flutter_application_1.bruno

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
